const express = require('express');
const app = express();
const port = process.env.PORT || 3000;
const mongoose = require('mongoose');
const bodyparser = require('body-parser');

app.use(bodyparser.urlencoded({extended:false}));
app.use(bodyparser.json());

const auth = require('./routes/api/auth');
const profile = require('./routes/api/profile');
const questions = require('./routes/api/questions');

// setting up the auth middleware
app.use('/api/auth', auth);

// setting up the profile middleware
app.use('/api/profile', profile);

// setting up the questions middleware
app.use('/api/questions', questions);

// database configuration
const db = require('./setup/myurl').mongoURL;

// Attempt to connect to database
mongoose
    .connect(db, {useNewUrlParser:true, useUnifiedTopology:true})
    .then( () => console.log('MongoDB connected successfully!'))
    .catch( err => console.log(err));

// routes - just for testing purpose
app.get('/', (req, res) => {
    res.send('Welcome to the big stack project!');
});

app.listen(port, () => {
    console.log('Server is listening at port '+port);
});