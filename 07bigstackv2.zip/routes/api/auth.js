const express = require('express');
const router = express.Router();
const Person = require('../../models/Person');
const bcrypt = require('bcryptjs');

// @type  GET
// @route /api/auth/
// @desc just a test api
// @access PUBLIC
router.get('/', (req, res) => res.json({test : "Auth api is success!"}));

// @type  POST
// @route /api/auth/register
// @desc route for registration of users
// @access PUBLIC

router.post('/register', (req, res) => {
    Person.findOne({email : req.body.email})
        .then( person => {
            // if person already exists
            if(person) {
                res.status(400)
                    .json({emailerror: "Email is already registered, Please login!"});
            }
            else{
                const newPerson = new Person({
                    name: req.body.name,
                    email: req.body.email,
                    password: req.body.password
                });

                // Encrypt password using bcrypt
                bcrypt.genSalt(10, (err, salt) => {
                    bcrypt.hash(newPerson.password, salt, (err, hash) => {
                        if( err ) throw err;
                        newPerson.password = hash;
                        // Store hash in your password DB.
                        newPerson
                            .save()
                            .then( person => res.json(person))
                            .catch( err => console.log(err));
                    });
                });
            }
        })
        .catch(err => console.log(err));
});

// @type  POST
// @route /api/auth/login
// @desc route for login of users
// @access PUBLIC

router.post('/login', (req, res)=> {
    const email = req.body.email;
    const password = req.body.password;

    Person.findOne({email})
        .then( person => {
            if(!person) {
                return res.status(404).json({ emailerror: 'User not found with this email!'});
            }
            else{
                bcrypt.compare(password, person.password)
                    .then( isMatch => {
                        if(isMatch){
                            res.json({success: 'User is able to login successfully!'});
                        }
                        else{
                            res.status(400).json({passworderror : 'Incorrect password!'});
                        }
                    })
                    .catch( err => console.log(err));
            }
        })
        .catch( err => console.log(err));
});

module.exports = router;