module.exports = {
    mongoURL : "mongodb+srv://rishab:rishab123@backendcourse-tyb6z.mongodb.net/test?retryWrites=true&w=majority",
    secret : "mystrongsecret"
};