const express = require('express');
const app = express();
const port = process.env.PORT || 3000;
const mongoose = require('mongoose');

// database configuration
const db = require('./setup/myurl').mongoURL;

// Attempt to connect to database
mongoose
    .connect(db, {useNewUrlParser:true, useUnifiedTopology:true})
    .then( () => console.log('MongoDB connected successfully!'))
    .catch( err => console.log(err));

// routes
app.get('/', (req, res) => {
    res.send('Welcome to the big stack project!');
});

app.listen(port, () => {
    console.log('Server is listening at port '+port);
});